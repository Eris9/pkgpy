from pkgpy import install
install()