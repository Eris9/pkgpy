from setuptools import setup

setup(name='pkgpy',
      version='0.3',
      description='pkgpy',
      url='http://github.com/eris9/pkgpy',
      author='Eris9/Sakurai07',
      author_email='blzzardst0rm@gmail.com',
      license='MIT',
      packages=['pkgpy'],
      zip_safe=False)